library("dplyr")
library(shiny)
library(arules)

names.df <- read.csv("https://www.finley-lab.com/files/data/name_list.csv")

# Define UI
ui <- fluidPage(
  titlePanel("Grocery(GRC) Dataset"),
  sidebarLayout(
    sidebarPanel(
      fileInput("dataset_path", "Upload Dataset (CSV format)"),
      numericInput("num_clusters", label = "Number of Clusters", min = 2, max = 4, value = 0), # Initialized with a default value
      numericInput("min_support", label = "Minimum Support", min = 0, max = 1, value = 0, step=0.1),
      numericInput("min_confidence", label = "Minimum Confidence", min = 0, max = 1, value = 0, step=0.1),
      actionButton("run", "Show Analysis ")
    ),
    mainPanel(
      conditionalPanel(
        condition = "input.run > 0",
        tabsetPanel(
          tabPanel("Data Visualization", plotOutput("plots"), verbatimTextOutput("data_summary")),
          tabPanel("Customer Details", tableOutput("customer_details_table")),
          tabPanel("Association Rules", tableOutput("association_rules_table"))
        )
      )
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  # Read uploaded dataset
  grc_data <- reactive({
    req(input$dataset_path)
    read.csv(input$dataset_path$datapath)
  })
  
  # Reactive value to track if analysis button is clicked
  analysis_clicked <- reactiveVal(FALSE)
  
  # Initialize dataset summary
  output$dataset_summary <- renderPrint({
    if (!analysis_clicked()) {
      "Please upload a dataset to see the summary."
    }
  })
  
  # Remove duplicates 
  observeEvent(input$dataset_path, {
    grc <- read.csv(input$dataset_path$datapath)
    # Remove duplicates
    unique_grc <- unique(grc)  #Removes duplicate rows from the dataset, keeping only unique rows.
    output$data_summary <- renderPrint({
      cat("Data cleaning Summary:\n")
      cat("Original rows:", nrow(grc), "\n")
      cat("Rows after removing duplicates:n", nrow(unique_grc), "\n")
    })
  })
  
  # Render plots
  output$plots <- renderPlot({
    grc <- grc_data() 
    
    par(mfrow=c(2,2))
    
    # Plot 1: Comparing cash and credit totals
    x <- table(grc$paymentType)
    percentage <- paste0(round(100 * x / sum(x)), "%")
    pie(x, main = "Compare cash and credit totals", col = c("chartreuse", "seagreen"), labels = percentage)
    legend("bottomright", legend = c("cash", "credit"), fill = c("chartreuse", "seagreen"))
    
    # Plot 2: Comparing each age and sum of total spending
    grc_grouped <- grc %>%
      group_by(age) %>%
      summarise(total_spending = sum(total))
    plot(x = grc_grouped$age, y = grc_grouped$total_spending,
         main = "Compare each age and sum of total spending",
         xlab = "Age", ylab = "Total Spending", col = "red")
    
    # Plot 3: Total Spending by City
    grc_grouped <- grc %>%
      group_by(city) %>%
      summarise(total_spending = sum(total)) %>%
      arrange(desc(total_spending))
    barplot(grc_grouped$total_spending, 
            names.arg = grc_grouped$city,
            xlab = "City", ylab = "Total Spending", 
            col = "purple",
            main = "Total Spending by City")
    
    # Plot 4: Distribution of total spending
    boxplot(grc$total, 
            main = "Distribution of Total Spending", 
            xlab = "Total Spending",
            col = "skyblue", 
            border = "darkblue")
  })
  
  # Perform k-means clustering and association rule mining 
  observeEvent(input$run, {
    analysis_clicked(TRUE)  # Update reactive value
    grc <- grc_data()
    
    # Display customer details with computed cluster number
    output$customer_details_table <- renderTable({
      if (!is.null(grc)) {
        # Perform clustering analysis for customer details
        clustring <- grc
        if ("customer" %in% names(clustring)) {
          clustring_summary <- clustring %>%
            group_by(customer, age) %>%
            summarise(total_spending = sum(total)) %>%
            as.data.frame()
        } else {
          clustring_summary <- clustring %>%
            group_by(age) %>%
            summarise(total_spending = sum(total)) %>%
            as.data.frame()
        }
        
        # Perform k-means clustering for customer details
        if (!is.null(input$num_clusters) && input$num_clusters >= 2 && input$num_clusters <= 4) {
          clustrs <- kmeans(clustring_summary[, "total_spending", drop = FALSE], centers = input$num_clusters)
          # Add cluster number as a column
          clustring_summary$cluster <- clustrs$cluster
        } else {
          showModal(modalDialog(
            title = "Invalid Input",
            "Please enter a valid number of clusters between 2 and 4.",
            easyClose = TRUE
          ))
          return(NULL)  # Return NULL if input is invalid
        }
        
        # Display customer details with computed cluster number
        clustring_summary
      }
    })
    
    # Perform association rule mining
    splitchr <- strsplit(as.character(grc$items), ",")
    transaction <- as(splitchr, "transactions")
    rules <- apriori(transaction, parameter = list(support = input$min_support, confidence = input$min_confidence, minlen = 2))
    
    # Render association rules table
    output$association_rules_table <- renderTable({
      as(rules, "data.frame")
    })
    
    # Output text
    output$kmeans_text <- renderText({
      "This is the result of k-means clustering:"
    })
    output$association_rules_text <- renderText({
      "The result of association rule mining:"
    })
  })
}
# Create Shiny app
shinyApp(ui = ui, server = server)